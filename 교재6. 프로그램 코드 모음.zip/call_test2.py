### call_test2.py
import my_module

a = int(input('Enter first number : '))
b = int(input('Enter second number : '))
        
ret_val = my_module.sumOfDouble(a, b)
print ('Result Value from sumOfDouble : ', ret_val)

ret_val = my_module.multipleOfDouble(a, b)
print ('Result Value from multipleOfDouble: ', ret_val)
