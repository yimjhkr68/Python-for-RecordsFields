### mult_num1.py
for multiplier in range(5,8):
    for i in range(1,10):
        print (multiplier, ' x ', i, ' = ', multiplier*i)
    print ('====================')
