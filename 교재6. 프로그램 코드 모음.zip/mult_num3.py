# mult_num3.py
### 구구단 함수의 인수를 의미없게  만들기

def xx(a, b):
    for c in range(a, b+1):
        for i in range(1,10):
            print (c, ' x ', i, ' = ', c * i)
        print('==================')


### 함수 호출하기

xx(3,5)
