#calc_wage.py

def calculateWage(role, time, overtime, night):
    base_wage = [6470, 8000, 10000]
    increase_rate = [15, 30]
    base = 0
    if role == 'Mate':
        base = base_wage[0]
    
    elif role == 'Manager':
        base = base_wage[1]
    
    elif role == 'Chief':
        base = base_wage[2]
    
    total_wage = base * time + base * (1 + increase_rate[0] * 0.01)
    + overtime *  base * (1 + increase_rate[1] * 0.01) * night
    
    return total_wage


RetVal = calculateWage('Mate', 6, 2, 3)
print (int(RetVal), 'won')
