# 함수 테스트 function_test.py

def printMyDepartment():
    print('Records and Archives Management')
    print()


printMyDepartment() # 첫번째 호출 
printMyDepartment() # 두번째 호출 

print('끝')

