### time_sleep2.py
from time import sleep

for i in range(10,0, -1):
    print (i)
    sleep(1)
print ('새해복많이 받으세요!!! ')
