### time_sleep1.py
import time

for i in range(10,0, -1):
    print (i)
    time.sleep(1)
print ('새해복많이 받으세요!!! ')
