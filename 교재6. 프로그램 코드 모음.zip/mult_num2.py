# mult_num2.py
### 구구단 함수 만들기

def intMultiplier(initNum, lastNum):
    for multiplier in range(initNum, lastNum+1):
        for i in range(1,10):
            print (multiplier, ' x ', i, ' = ', multiplier * i)
        print('==================')


### 함수 호출하기

intMultiplier(3,5)
