#"my_module.py" file
# Other program may use this file

def sumOfDouble(arg1, arg2):
    print ('sumOfDouble function in my_module')
    val1 = arg1 * 2
    val2 = arg2 * 2
    return val1+val2

def multipleOfDouble(arg1, arg2):
    print ('multipleOfDouble function in my_module')
    val1 = arg1 * 2
    val2 = arg2 * 2
    return val1 * val2
