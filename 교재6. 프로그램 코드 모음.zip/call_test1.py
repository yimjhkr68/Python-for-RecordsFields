### call_test1.py
import my_module

a = int(input('Enter first number : '))
b = int(input('Enter second number : '))
        
ret_val = sumOfDouble(a, b)
print ('Result Value : ', ret_val)
