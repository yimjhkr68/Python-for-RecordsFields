# file_rename1.py

import os

path = r"C:\Temp"
print (os.listdir(path))

os.chdir(path)

os.rename("pmp.jpg", "xxx.jpg")

print (os.listdir(path))
