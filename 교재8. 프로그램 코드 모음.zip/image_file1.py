# image_file1.py

import os


# Read files from the directory (binary mode)
dir_name =  r"C:\Temp"

file_names = os.listdir(dir_name)
print (file_names)
