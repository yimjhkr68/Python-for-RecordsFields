# 클래스 계층구조 테스트  class_test.py
### 부모클래스 정의하기 
class Ball:
    print ('Parent Class Ball!!!')
    color = 'white'
    def bounce(self):
        if self.direction == 'down':
            self.direction = 'up'
        elif self.direction == 'up':
            self.direction = 'down'

### 자식클래스 정의하기 
class TennisBall(Ball):
    print ('Child Class TennisBall!!!')
    size = 'middle'
    def hit(self):
        if self.position == 'head':
           self.spin = 'Topspin'
        elif self.position == 'underneath':
            self.spin = 'Backspin'

# 부모클래스 인스턴스 만들기 
PBall = Ball()
print (PBall.__dict__)
print (PBall.color)
PBall.color = 'red'
PBall.size = 'big'
PBall.direction = 'down'
print (PBall.__dict__)

# 자식클래스 인스턴스 만들기 
CBall = TennisBall()
print (CBall.__dict__)
CBall.spin = None
CBall.position = 'head'
print (CBall.__dict__)
print (CBall.color)
print (CBall.size)


# 자식 인스턴스의 자기 메서드 호출하기1
CBall.hit()
print (CBall.__dict__)

CBall.position = 'underneath'
CBall.hit()
print (CBall.__dict__)

# 자식 인스턴스의 부모 메서드 호출하기
CBall.direction = 'up'
CBall.bounce()
print (CBall.__dict__)

