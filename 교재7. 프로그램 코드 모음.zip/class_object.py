### class_object.py
# 클래스 정의하기 class_object.py
class Ball:
    print ('Class Ball!!!')
    color = 'white'
    def bounce(self):
        if self.direction == "down":
            self.direction = "up"
        elif self.direction == "up":
            self.direction = "down"

# 인스턴스 만들기 
myBall = Ball()
print (myBall.color)

# 인스턴스의 속성값 변경하기 
myBall.color = 'red'

# 인스턴스에 속성 추가하기 
myBall.size = 'big'
myBall.direction = 'down'

# 인스턴스 속성값 확인하기 
print (myBall.color)
print (myBall.size)
print (myBall.direction)

# 인스턴스의 메서드 호출하기 
print ('Call bounce method!')
myBall.bounce()
print (myBall.__dict__)

# 인스턴스의 메서드 반복 호출하기 
print ('Call bounce method!')
myBall.bounce()
print (myBall.__dict__)
